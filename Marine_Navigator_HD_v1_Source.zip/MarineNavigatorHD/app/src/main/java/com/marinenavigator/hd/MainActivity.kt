package com.marinenavigator.hd

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.views.overlay.MapEventsOverlay
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : android.app.Activity(), LocationListener {
    private lateinit var map: MapView
    private lateinit var status: TextView
    private lateinit var locationManager: LocationManager
    private var myLocation: GeoPoint? = null
    private val waypoints = mutableListOf<GeoPoint>()
    private var routeLine: Polyline? = null
    private val requestCode = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = TextView(this).apply {
            text = "MARINE NAVIGATOR HD  •  CEBU"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF073B4C.toInt())
            setPadding(18, 16, 18, 16)
        }
        status = TextView(this).apply {
            text = "General map only • Depth data not loaded"
            textSize = 12f
            setPadding(12, 8, 12, 8)
        }
        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(10.5)
            controller.setCenter(GeoPoint(10.3157, 123.8854))
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(4, 4, 4, 4)
        }
        fun button(label: String, action: () -> Unit) {
            buttons.addView(Button(this).apply { text = label; setOnClickListener { action() } },
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        button("My GPS") { requestLocation() }
        button("Add point") { addWaypointAtCenter() }
        button("Route") { drawRoute() }
        button("Clear") { clearWaypoints() }

        root.addView(header)
        root.addView(status)
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buttons)
        setContentView(root)

        val receiver = object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean {
                p?.let { addWaypoint(it) }
                return true
            }
            override fun longPressHelper(p: GeoPoint?): Boolean = false
        }
        map.overlays.add(MapEventsOverlay(receiver))
        loadWaypoints()
        redrawWaypoints()
    }

    private fun requestLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), requestCode)
            return
        }
        try {
            val provider = if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER
            locationManager.requestLocationUpdates(provider, 2000L, 5f, this)
            val last = locationManager.getLastKnownLocation(provider)
            if (last != null) onLocationChanged(last) else status.text = "Waiting for GPS fix…"
        } catch (e: Exception) {
            status.text = "Location unavailable: ${e.localizedMessage ?: "check permission"}"
        }
    }

    override fun onLocationChanged(location: Location) {
        myLocation = GeoPoint(location.latitude, location.longitude)
        map.overlays.removeAll { it is Marker && it.title == "Your location" }
        val marker = Marker(map).apply {
            position = myLocation
            title = "Your location"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        }
        map.overlays.add(marker)
        map.controller.animateTo(myLocation)
        status.text = "GPS: %.5f, %.5f • General map only; no depth data".format(location.latitude, location.longitude)
        map.invalidate()
    }

    private fun addWaypointAtCenter() = addWaypoint(map.mapCenter as GeoPoint)

    private fun addWaypoint(point: GeoPoint) {
        waypoints.add(GeoPoint(point.latitude, point.longitude))
        saveWaypoints()
        redrawWaypoints()
        Toast.makeText(this, "Waypoint saved", Toast.LENGTH_SHORT).show()
    }

    private fun redrawWaypoints() {
        map.overlays.removeAll { it is Marker && (it.title?.startsWith("Waypoint") == true) }
        waypoints.forEachIndexed { index, point ->
            map.overlays.add(Marker(map).apply {
                position = point
                title = "Waypoint ${index + 1}"
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            })
        }
        map.invalidate()
    }

    private fun drawRoute() {
        routeLine?.let { map.overlays.remove(it) }
        if (waypoints.size < 2) {
            Toast.makeText(this, "Add at least two waypoints", Toast.LENGTH_SHORT).show()
            return
        }
        routeLine = Polyline().apply { setPoints(waypoints) }
        map.overlays.add(routeLine)
        map.invalidate()
        Toast.makeText(this, "Straight-line preview only — not a safe navigational route", Toast.LENGTH_LONG).show()
    }

    private fun clearWaypoints() {
        waypoints.clear()
        routeLine?.let { map.overlays.remove(it) }
        routeLine = null
        saveWaypoints()
        redrawWaypoints()
        status.text = "Waypoints cleared • General map only; no depth data"
    }

    private fun saveWaypoints() {
        val array = JSONArray()
        waypoints.forEach { array.put(JSONObject().put("lat", it.latitude).put("lon", it.longitude)) }
        getSharedPreferences("marine", MODE_PRIVATE).edit().putString("waypoints", array.toString()).apply()
    }

    private fun loadWaypoints() {
        val raw = getSharedPreferences("marine", MODE_PRIVATE).getString("waypoints", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                waypoints.add(GeoPoint(item.getDouble("lat"), item.getDouble("lon")))
            }
        } catch (_: Exception) { waypoints.clear() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestLocation()
        else status.text = "GPS permission not granted"
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { super.onPause(); map.onPause(); try { locationManager.removeUpdates(this) } catch (_: Exception) {} }
}
